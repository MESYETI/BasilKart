#ifndef BK_TITLESCREEN_H
#define BK_TITLESCREEN_H

#include "scene.h"

Scene TitlescreenScene(void);

#endif

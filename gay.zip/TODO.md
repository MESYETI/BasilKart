# TODO
- [ ] Apply fog to sprites

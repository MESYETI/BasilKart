#ifndef BK_TYPES_H
#define BK_TYPES_H

typedef struct {
	int x, y;
} Vec2;

typedef struct {
	double x, y;
} FVec2;

#endif

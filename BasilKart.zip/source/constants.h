#ifndef BK_CONSTANTS_H
#define BK_CONSTANTS_H

#define APP_NAME          "Basil Kart"
#define APP_WIN_WIDTH     320
#define APP_WIN_HEIGHT    240
#define APP_FOV           90
#define APP_TILE_WIDTH    32
#define APP_TILE_HEIGHT   32
#define APP_UI_SLICE_SIZE 8

#endif

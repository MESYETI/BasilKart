#ifndef BK_PLATFORM_H
#define BK_PLATFORM_H

void Platform_Init(void);
void Platform_Free(void);

#endif

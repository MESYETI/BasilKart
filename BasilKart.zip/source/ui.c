#include "ui.h"
#include "safe.h"

static void TableFree(UIElement* element) {
	
}

static void TableHandleEvent(UIElement* element, SDL_Event* event) {
	
}

static void TableRender(UIElement* element, bool focused) {
	
}

UIElement UI_NewTable(size_t length) {
	UIElement ret;
	ret.data        = (void*) NEW(UITable);
	ret.free        = &TableFree;
	ret.handleEvent = &TableHandleEvent;
	ret.render      = &TableRender;

	UITable* table = (UITable*) &ret.data;
	table->entries = SafeMalloc(sizeof(UITableEntry) * length);
	table->length  = length;

	return ret;
}

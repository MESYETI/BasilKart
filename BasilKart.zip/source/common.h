#ifndef BK_COMMON_H
#define BK_COMMON_H

#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>
#include <sys/param.h>

#include <SDL2/SDL.h>
#undef main

#define PI 3.14159265359

#endif

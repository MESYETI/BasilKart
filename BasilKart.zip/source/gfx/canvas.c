#include <stdio.h>
#include "canvas.h"
#include "../safe.h"

void GFX_NewCanvas(GFX_Canvas* canvas, int width, int height) {
	canvas->width  = width;
	canvas->height = height;
	canvas->pixels = SafeMalloc(width * height * sizeof(GFX_Colour));
}

void GFX_FreeCanvas(GFX_Canvas* canvas) {
	free(canvas->pixels);
}

GFX_Colour GFX_RGBToColour(uint8_t r, uint8_t g, uint8_t b, uint8_t a) {
	return r | (g << 8) | (b << 16) | (a << 24);
}

void GFX_DrawPixel(GFX_Canvas* canvas, int x, int y, GFX_Colour col) {
	if ((x >= canvas->width) || (y >= canvas->height) || (x < 0) || (y < 0)) {
		return;
	}

	canvas->pixels[(y * canvas->width) + x] = col;
}

void GFX_ClearCanvas(GFX_Canvas* canvas, uint8_t r, uint8_t g, uint8_t b) {
	uint32_t colour = GFX_RGBToColour(r, g, b, 255);

	for (int i = 0; i < canvas->width * canvas->height; ++ i) {
		canvas->pixels[i] = colour;
	}
}

GFX_Colour GFX_GetPixel(GFX_Canvas* canvas, int x, int y) {
	if ((x < 0) || (y < 0) || (x >= canvas->width) || (y >= canvas->height)) {
		printf("Out of bounds: %d %d\n", x, y);
		assert(0);
	}

	return canvas->pixels[(y * canvas->width) + x];
}

void GFX_CropCanvas(GFX_Canvas* dest, GFX_Canvas* src, int x, int y, int w, int h) {
	GFX_NewCanvas(dest, w, h);

	for (int ix = x; ix - x < w; ++ ix) {
		for (int iy = y; iy - y < h; ++ iy) {
			GFX_DrawPixel(dest, ix - x, iy - y, GFX_GetPixel(src, ix, iy));
		}
	}
}

#ifndef BK_UI_H
#define BK_UI_H

#include <SDL2/SDL.h>
#include "util.h"
#include "common.h"

struct UIElement;

struct UIElement {
	void* data;

	FUNCTION_POINTER(void, free, struct UIElement*);
	FUNCTION_POINTER(void, handleEvent, struct UIElement*, SDL_Event*);
	FUNCTION_POINTER(void, render, struct UIElement*, bool focused);
};

typedef struct UIElement UIElement;

struct UITableEntry;

struct UITableEntry {
	void* data;

	FUNCTION_POINTER(void, free, struct UITableEntry*);
	FUNCTION_POINTER(void, handleEvent, struct UITableEntry*, SDL_Event*);
	FUNCTION_POINTER(void, onAction, struct UITableEntry*);
	FUNCTION_POINTER(void, render, struct UITableEntry*, bool focused, bool selected);
};

typedef struct UITableEntry UITableEntry;

typedef struct {
	UITableEntry* entries;
	size_t        length;
} UITable;

UIElement UI_NewTable(size_t length);

#endif

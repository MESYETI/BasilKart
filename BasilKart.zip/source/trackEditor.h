#ifndef BK_TRACK_EDITOR_H
#define BK_TRACK_EDITOR_H

#include "ui.h"
#include "map.h"
#include "game.h"

Scene TrackEditorScene(void);

#endif
